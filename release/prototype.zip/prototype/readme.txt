Controls for Rain Rain Go Away

1. A/D Key: Horizontal Movement On Platform

2. Mouse Horizontal Movement
- Left horizontal movement of mouse will cause the umbrella to turn counter clockwise. 
- Right horizontal movement of mouse will cause the umbrella to turn clockwise

3. Left/Right Arrow Key
This is an alternative way to cause umbrella movement.
- Left Arrow: Counter Clockwise Turn
- Right Arrow: Clockwise Turn

4. R Key: Reset to Start Position

5. B Key: Turn on debug mode

Basic Interactions

1. Wind/Umbrella Interaction: Orientation of the umbrella and wind determines the direction and magnitude of wind force acting upon the player.

2. Platform/Player Interaction: Allows horizontal movement on platform. 

3. Out of Bound: Currently, the player will reset when going out of bounds. However, our game will be scrollable, so this is a feature that is only implemented to test the user controls.